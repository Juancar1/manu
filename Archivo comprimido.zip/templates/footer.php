

 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2016-2018 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
    reserved. Developed: <strong> Juancar Pliego</strong>
  </footer>
</div>


<!-- jQuery 3 -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="js/bootstrap3-wysihtml5.all.min.js"></script>

<script src="js/jquery-ui.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="js/bootstrap.min.js"></script>
<!-- lightbox -->
<script src="js/lightbox.min.js"></script>
<!-- calendario -->
<!-- login 3.3.7 -->
<script src="js/login-ajax.js"></script>
<!-- admin ajax -->
<script src="js/trabajadores-ajax.js"></script>
<!-- SlimScroll -->
<script src="js/jquery.slimscroll.min.js"></script>
<!-- bootstrap time picker -->
<script src="js/bootstrap-timepicker.min.js"></script>
<!-- FastClick -->
<script src="js/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>
<!-- AdminLTE App -->
<script src="js/sweetalert2.all.min.js"></script> 
<!-- Countdown -->
<script src="js/jquery.countdown.min.js"></script>
<!-- Login ajax -->
<script src="js/demo.js"></script>
<!-- emails -->
<script src="js/email.js"></script>
<!-- estado de las fiestas "archivados" -->
<script src="js/fiestas-estado.js"></script>
<!-- Select2 -->
<script src="js/select2.full.min.js"></script>
<!-- Ionicons -->
<link rel="stylesheet" href="js/ionicons.min.css">
<!-- iCheck -->
<script src="js/icheck.min.js"></script>
<!-- Login ajax -->
<script src="js/nota-ajax.js"></script>
<!-- Ajax trabajadores -->
<script src="js/trabajadores.js"></script>
<!-- Ajax y notificaciones admin -->
<script src="js/admin.js"></script>
<!-- Alertas admin-->
<script src="js/admin-notificaciones.js"></script>
<!-- CK Editor -->
<script src="js/ckeditor.js"></script>
<!-- PDF -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
<!-- HTML2CANVAS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js"></script>
<!-- buscador -->
<script src="js/buscador.js"></script>
<script type="text/javascript" src="js/datepicker-es.js" charset="UTF-8"></script>
<!-- CK Editor -->
<script src="js/pdf.js"></script>
<script>

  
  $(document).ready(function () {
    $('.sidebar-menu').tree()
  })

  $(".compose-textarea").wysihtml5();

  // $(document).ready(function () {
  // $('.foto-perfil').colorbox({inline:true, width: "50%"});
  // })
</script>

</body>
</html>
